require 'test_helper'

class SettingGroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
