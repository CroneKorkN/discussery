$.fn.topic =  function(){
  $(this).find("[data-send-answer]").answer();
}